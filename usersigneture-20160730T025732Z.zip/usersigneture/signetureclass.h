//
//  signetureclass.h
//  usersigneture
//
//  Created by MACOS on 22/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UviSignatureView.h"


@protocol signetureclassdelegate <NSObject>


@required
-(void)processcompleted:(UIImage *)signImage;


@end
@interface signetureclass : UIViewController
{
    
    id <signetureclassdelegate> _delegate;
     NSString *userName, *signedDate;
}
@property (nonatomic,strong) id delegate;

-(void)startsampleprocess:(NSString *)text;

- (IBAction)captureaction:(id)sender;
@property (weak, nonatomic) IBOutlet UviSignatureView *capture;

@end
