//
//  ViewController.h
//  usersigneture
//
//  Created by MACOS on 22/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "signetureclass.h"
@interface ViewController : UIViewController<signetureclassdelegate>

- (IBAction)btnclick:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *imgview;

@end

