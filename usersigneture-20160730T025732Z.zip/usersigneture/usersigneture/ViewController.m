//
//  ViewController.m
//  usersigneture
//
//  Created by MACOS on 22/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "signetureclass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGFloat borderWidth = 2.0f;
    
    self.imgview.layer.borderColor = [UIColor grayColor].CGColor;
    self.imgview.layer.borderWidth = borderWidth;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)processcompleted:(UIImage *)signImage
{
    
    _imgview.image = signImage;
    
}

- (IBAction)btnclick:(id)sender {
    
    
    signetureclass *obj =[self.storyboard instantiateViewControllerWithIdentifier:@"next"];
    
    obj.delegate=self;
    
    [self.navigationController pushViewController:obj animated:YES];
    
    
}
@end
